#!/bin/sh

/sbin/ip route add default via 192.168.101.6 table 6

